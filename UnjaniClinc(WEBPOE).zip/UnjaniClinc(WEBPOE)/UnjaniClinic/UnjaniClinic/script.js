/* -------------------------------
   Unjani Clinic - Full JS
   Features:
   - Contact & Enquiry Forms
   - Email Options + WhatsApp
   - Popup Success Animations
   - Lightbox Gallery
   - Accordion with Animation
   - Dynamic Search / Filter
---------------------------------*/
/* -------------------------------
   Unjani Clinic - Full JS
---------------------------------*/

/* --------------------------
   1. Utility Functions
-------------------------- */
function qs(selector) {
    return document.querySelector(selector);
}

function qsa(selector) {
    return document.querySelectorAll(selector);
}

/* --------------------------
   2. Contact Form Validation
-------------------------- */
function validateContactForm() {
    let isValid = true;

        const nameInput = qs("#contact_name");
        const emailInput = qs("#contact_email");
        const purposeInput = qs("#contact_purpose");
         const messageInput = qs("#contact_message");

        qsa(".error").forEach(e => e.textContent = "");

    if (nameInput.value.trim() === "") {
         qs("#nameError").textContent = "Name is required";
         qs("#nameError").style.color = "red";
            isValid = false;
    }

    if (emailInput.value.trim() === "") {
         qs("#emailError").textContent = "Email is required";
         qs("#emailError").style.color = "red";
         isValid = false;
    }   else if (!emailInput.value.includes("@")) {
             qs("#emailError").textContent = "Invalid email address";
             qs("#emailError").style.color = "red";
             isValid = false;
    }

    if (purposeInput.value === "") {
             qs("#purposeError").textContent = "Please select a purpose";
             qs("#purposeError").style.color = "red";
             isValid = false;
    }

    if (messageInput.value.trim() === "") {
              qs("#messageError").textContent = "Message cannot be empty";
             qs("#messageError").style.color = "red";
             isValid = false;
    }

            return isValid;
}

        /* --------------------------
         3. Contact Form Email Sender
        -------------------------- */
    function sendEmail(provider) {
         if (!validateContactForm()) return;

         const name = encodeURIComponent(qs("#contact_name").value);
         const email = encodeURIComponent(qs("#contact_email").value);
         const purpose = encodeURIComponent(qs("#contact_purpose").value);
         const message = encodeURIComponent(qs("#contact_message").value);

     let mailto = "";

        switch (provider) {
         case "default":
              mailto = `mailto:someone@example.com?subject=${purpose}&body=Name:%20${name}%0AEmail:%20${email}%0AMessage:%20${message}`;
            break;
         case "gmail":
              mailto = `https://mail.google.com/mail/?view=cm&fs=1&to=someone@example.com&su=${purpose}&body=Name:%20${name}%0AEmail:%20${email}%0AMessage:%20${message}`;
             break;
         case "outlook":
              mailto = `https://outlook.office.com/mail/deeplink/compose?to=someone@example.com&subject=${purpose}&body=Name:%20${name}%0AEmail:%20${email}%0AMessage:%20${message}`;
                 break;
        case "yahoo":
              mailto = `https://compose.mail.yahoo.com/?to=someone@example.com&subject=${purpose}&body=Name:%20${name}%0AEmail:%20${email}%0AMessage:%20${message}`;
             break;
         case "whatsapp":
               mailto = `https://wa.me/1234567890?text=Name:%20${name}%0AEmail:%20${email}%0AMessage:%20${message}`;
              break;
    }

         window.location.href = mailto;
}

            /* --------------------------
             4. Enquiry Form Validation
            -------------------------- */
    function validateEnquiryForm() {
         let isValid = true;

             const nameInput = qs("#enq_name");
             const emailInput = qs("#enq_email");
            const phoneInput = qs("#enq_phone");
            const serviceInput = qs("#enq_service");
             const quantityInput = qs("#enq_quantity");

         qsa(".enqError").forEach(e => e.textContent = "");

    if (nameInput.value.trim() === "") {
             qs("#enqNameError").textContent = "Name is required";
             qs("#enqNameError").style.color = "red";
             isValid = false;
    }

    if (emailInput.value.trim() === "") {
             qs("#enqEmailError").textContent = "Email is required";
                qs("#enqEmailError").style.color = "red";
             isValid = false;
    } else if (!emailInput.value.includes("@")) {
             qs("#enqEmailError").textContent = "Invalid email address";
             qs("#enqEmailError").style.color = "red";
             isValid = false;
    }

    if (phoneInput.value.trim() === "") {
              qs("#enqPhoneError").textContent = "Phone number is required";
             qs("#enqPhoneError").style.color = "red";
              isValid = false;
    }

    if (serviceInput.value === "") {
             qs("#enqServiceError").textContent = "Please select a service";
             qs("#enqServiceError").style.color = "red";
             isValid = false;
    }

    if (quantityInput.value <= 0 || quantityInput.value === "") {
             qs("#enqQuantityError").textContent = "Enter a valid quantity";
             qs("#enqQuantityError").style.color = "red";
             isValid = false;
    }

         return isValid;
}

            /* --------------------------
               5. Enquiry Cost Calculation
            -------------------------- */
    function calculateEnquiryCost() {
         if (!validateEnquiryForm()) return;

            const service = qs("#enq_service").value;
             const quantity = Number(qs("#enq_quantity").value);
             let costPerUnit = 0;

    switch (service) {
        case "general-consultation":
            costPerUnit = 200;
            break;
        case "chronic-care":
            costPerUnit = 150;
            break;
        case "maternal-child":
            costPerUnit = 250;
            break;
        case "immunization":
            costPerUnit = 100;
            break;
    }

         const total = costPerUnit * quantity;
         qs("#enq_result").textContent = `Estimated Total Cost: R${total}`;
        qs("#enq_result").style.color = "green";
}

        /* --------------------------
         6. Event Listeners
        -------------------------- */
            // Contact Form
        qs("#contactForm")?.addEventListener("submit", (e) => {
             e.preventDefault();
             sendEmail("default");
    });

            // Email buttons dynamically
        const emailOptions = qs("#emailOptions");
    if (emailOptions) {
         ["gmail", "outlook", "yahoo", "whatsapp"].forEach(provider => {
              const btn = document.createElement("button");
             btn.type = "button";
             btn.textContent = `Send via ${provider.charAt(0).toUpperCase() + provider.slice(1)}`;
              btn.addEventListener("click", () => sendEmail(provider));
               emailOptions.appendChild(btn);
     });
}

                        // Enquiry Form
        qs("#enq_calculate")?.addEventListener("click", calculateEnquiryCost);

        qs("#enquiryForm")?.addEventListener("submit", (e) => {
             e.preventDefault();
            if (validateEnquiryForm()) {
              alert("Enquiry submitted successfully!");
             qs("#enquiryForm").reset();
             qs("#enq_result").textContent = "";
        }
});
