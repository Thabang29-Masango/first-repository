/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import quickchatapp.Login;

/**
 *
 * @author RC_Student_lab
 */
public class LoginTest {
    Login user;
    @Test
    public void testCheckUserName_Valid() {
        Login login = new Login("abc_d", "Passw0rd!", "+27792285688", "Thabang", "Masango");
        assertTrue(login.checkUserName());
    }

    @Test
    public void testCheckUserName_Invalid() {
        Login login = new Login("abcde", "Passw0rd!", "+27792285688", "Thabang", "Masango");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        Login login = new Login("abc_d", "weakpwd", "+27792285688", "Thabang", "Masango");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        Login login = new Login("abc_d", "Passw0rd!", "+27792285688", "Thabang", "Masango");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        Login login = new Login("abc_d", "Passw0rd!", "0831234567", "Thabang", "Masango");
        assertFalse(login.checkCellPhoneNumber());
    }

    @Test
    public void testRegisterUser_AllValid() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        assertEquals("User registerd successfully", login.registerUser());
    }

    @Test
    public void testLoginUser_Success() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        assertTrue(login.loginUser("abc_d", "Good1@Pwd"));
    }

    @Test
    public void testLoginUser_Failure() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        assertFalse(login.loginUser("wrong_user", "Good1@Pwd"));
    }

    @Test
    public void testReturnLoginStatus_Success() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        String result = login.returnLoginStatus(true);
        assertTrue(result.contains("Welcome John, Doe"));
    }

    @Test
    public void testReturnLoginStatus_Failure() {
        Login login = new Login("abc_d", "Good1@Pwd", "+27792285688", "Thabang", "Masango");
        String result = login.returnLoginStatus(false);
        assertEquals("Username or password incorrect, please try again.", result);
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
// ST10487025
// Thabang Kenneth Masango