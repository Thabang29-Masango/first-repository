
package quickchatapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import javax.swing.JOptionPane;



public class Message {
    private static int totalMessages = 0;
    private static int messageNumber = 0;
    private static String[] sentMessages = new String[100];
    private String messageID;
    private String recipient;
    private String message;
    
    public Message(String recipient, String message) {
        this.messageID = String.format("%010d", new Random().nextInt(1000000000));
        this.recipient = recipient;
        this.message = message;
    }


      public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+27") && recipient.length() == 12 && allDigits(recipient.substring(3));
    }

    private boolean allDigits(String s) {
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return messageID.substring(0, 2) + ":" + messageNumber + ":" + first.toUpperCase() + last.toUpperCase();
    }

    public String sendMessageOption(int option) {
        switch (option) {
            case 1:
                totalMessages++;
                messageNumber++;
                sentMessages[totalMessages - 1] = toString();
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    public void storeMessage() {
        try (FileWriter file = new FileWriter("messages.txt", true)) {
           file.write("Message ID: " + messageID + "\n");
           file.write("Message Hash: " + createMessageHash() + "\n");
           file.write("Recipient: " + recipient + "\n");
           file.write("Message: " + message + "\n");
           file.write("-------------------------\n");
       } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
      }
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) {
            sb.append(sentMessages[i]).append("\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    @Override
    public String toString() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + createMessageHash() +
                "\nRecipient: " + recipient +
                "\nMessage: " + message;
    }

      
    
        
}
// ST10487025
// Thabang Kenneth Masango