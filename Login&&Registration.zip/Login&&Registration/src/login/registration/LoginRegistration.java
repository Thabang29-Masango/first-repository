
package login.registration;
import java.util.regex.Pattern;
import java.util.Scanner;
public class LoginRegistration {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         Scanner scanner = new Scanner(System.in);

        System.out.println("=== Register User ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter cellphone number (with international code): ");
        String cellphone = scanner.nextLine();

        Main.Login login = new Main.Login(username, password, cellphone);
        String registrationMessage = login.registerUser ();
        System.out.println(registrationMessage);

        if (!registrationMessage.equals("User  registered successfully.")) {
            System.out.println("Please fix the errors and try again.");
            scanner.close();
            return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
    }
        // Main class containing Login class and main method
public class Main {

    // Login class with required methods
    public static class Login {
        private String username;
        private String password;
        private String cellphoneNumber;
        private String returnLoginStatus;

        public Login(String username, String password, String cellphoneNumber) {
            this.username = username;
            this.password = password;
            this.cellphoneNumber = cellphoneNumber;
            this.returnLoginStatus = "";
        }

        // Username must contain underscore and be no more than 5 chars
        public boolean checkUsername() {
            boolean valid = username.contains("_") && username.length() <= 5;
            if (valid) {
                System.out.println("username successfully captured");
            } else {
                System.out.println("username is not correctly formatted please ensure that your username contain an underscore, and is no more than five characters length");
            }
            return valid;
        }

        // Password complexity: min 8 chars, at least one uppercase, one number, one special char
        public boolean checkPasswordComplexity() {
            boolean length = password.length() >= 8;
            boolean uppercase = Pattern.compile("[A-Z]").matcher(password).find();
            boolean number = Pattern.compile("[0-9]").matcher(password).find();
            boolean specialChar = Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();

            boolean valid = length && uppercase && number && specialChar;

            if (valid) {
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("A password should contain at least eight characters long, a capital letter, a number, and a special character.");
            }
            return valid;
        }

        // Cellphone number must have international code + country code + number, no more than 10 digits after code
        public boolean checkCellphoneNumber() {
            // Pattern: + followed by 1-3 digit country code, then up to 10 digits number
            // Total length max: + + country code (1-3 digits) + number (max 10 digits)
            // Example: +27XXXXXXXXX (SA number with 9 digits after country code)
            boolean valid = cellphoneNumber.matches("^\\+\\d{1,3}\\d{1,10}$");
            if (valid) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cellphone number incorrectly formatted or does not contain international code.");
            }
            return valid;
        }

        // Register user: returns message based on validations
        public String registerUser () {
            boolean usernameValid = checkUsername();
            boolean passwordValid = checkPasswordComplexity();
            boolean cellphoneValid = checkCellphoneNumber();

            if (usernameValid && passwordValid && cellphoneValid) {
                return "User  registered successfully.";
            } else {
                return "User  registration failed due to invalid input.";
            }
        }

        // Login user: check if input username and password match stored ones
        public boolean loginUser (String inputUsername, String inputPassword) {
            boolean success = inputUsername.equals(this.username) && inputPassword.equals(this.password);
            if (success) {
                returnLoginStatus = "welcome, " + inputUsername + ", it is great to see you again.";
            } else {
                returnLoginStatus = "username or password incorrect. Please try again.";
            }
            System.out.println(returnLoginStatus);
            return success;
        }

        // Return login status message
        public String returnLoginStatus() {
            return returnLoginStatus;
        }
    }

    
   
    
}
}
